main :: IO ()
main = do
  --Eingabe
  putStrLn ("Wie ist dein Name?")
  nameDesBenutzers <-getLine
  --Ausgabe
  putStrLn ("Hallo "++nameDesBenutzers++"!")