import java.util.Scanner;
//^Für den Input benötigt

class u1
{
    public static void main (String[] args)
    {
        //Für den Input benötigt
        Scanner scanner = new Scanner(System.in);

        //Eingabe
        System.out.println("Wie ist dein Name?"); 
        String nameDesBenutzers = scanner.nextLine();   
        //Ausgabe
        System.out.println("Hallo "+nameDesBenutzers+"!"); 
    }
}