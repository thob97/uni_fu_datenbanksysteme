#Die Eingabe
nameDesBenutzers = str(input("Wie ist dein Name?\n"))
#Die Ausgabe
print ("Hallo " + nameDesBenutzers + "!")